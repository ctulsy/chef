default['webapp-linux']['user'] = 'web_admin'
default['webapp-linux']['group'] = 'web_admin'

default['webapp-linux']['document_root'] = '/var/www/customers/public_html'

default['firewall']['allow_ssh'] = true
